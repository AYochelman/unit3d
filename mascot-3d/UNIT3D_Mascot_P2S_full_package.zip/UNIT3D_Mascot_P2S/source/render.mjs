// Render GLB files of the ACTUAL print geometry with three.js in headless Chromium.
// usage: node render.mjs jobs.json
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');

const ROOT = path.dirname(new URL(import.meta.url).pathname);
const jobs = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));

const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  let p = u.startsWith('/abs/') ? u.slice(4) : path.join(ROOT, u);
  if (!fs.existsSync(p)) { res.statusCode = 404; return res.end('nf'); }
  const ext = path.extname(p);
  const types = { '.js': 'text/javascript', '.html': 'text/html', '.glb': 'model/gltf-binary' };
  res.setHeader('Content-Type', types[ext] || 'application/octet-stream');
  fs.createReadStream(p).pipe(res);
});
await new Promise(r => server.listen(0, r));
const port = server.address().port;

const html = `<!doctype html><html><head><style>html,body{margin:0;background:#000}</style>
<script type="importmap">{"imports":{"three":"/node_modules/three/build/three.module.js","three/addons/":"/node_modules/three/examples/jsm/"}}</script>
</head><body><script type="module">
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
window.renderJob = async (job) => {
  const W = job.width, H = job.height;
  const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
  renderer.setPixelRatio(1); renderer.setSize(W, H);
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = job.exposure || 1.05;
  document.body.appendChild(renderer.domElement);
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(job.background || '#171b21');
  const gltf = await new GLTFLoader().loadAsync(job.glb);
  const root = gltf.scene;
  root.rotation.x = -Math.PI / 2;  // Z-up (print/CAD) -> Y-up (three)
  root.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true;
      const c = o.material.color.clone();
      o.material = new THREE.MeshStandardMaterial({ color: c, roughness: 0.55, metalness: 0.0, flatShading: false });
      if (o.geometry) o.geometry.computeVertexNormals();
  }});
  scene.add(root);
  root.updateMatrixWorld(true);
  const bb = new THREE.Box3().setFromObject(root);
  const ctr = bb.getCenter(new THREE.Vector3()); const size = bb.getSize(new THREE.Vector3());
  if (job.ground !== false) {
    const g = new THREE.Mesh(new THREE.PlaneGeometry(2000, 2000), new THREE.ShadowMaterial({ opacity: 0.35 }));
    g.rotation.x = -Math.PI / 2; g.position.y = bb.min.y - 0.01; g.receiveShadow = true; scene.add(g);
    if (job.grid) { const gh = new THREE.GridHelper(job.grid.size, job.grid.div, 0x55606e, 0x2c333d);
      gh.position.set(job.grid.cx||0, bb.min.y + 0.02, job.grid.cz||0); scene.add(gh); }
  }
  scene.add(new THREE.HemisphereLight(0xffffff, 0x2a3038, 1.15));
  const key = new THREE.DirectionalLight(0xffffff, 2.1);
  const R = Math.max(size.x, size.y, size.z);
  key.position.set(ctr.x - R * 1.2, ctr.y + R * 2.0, ctr.z + R * 1.6); key.target.position.copy(ctr);
  key.castShadow = true; key.shadow.mapSize.set(2048, 2048);
  const sc = key.shadow.camera; sc.left = -R * 1.5; sc.right = R * 1.5; sc.top = R * 1.5; sc.bottom = -R * 1.5; sc.near = 1; sc.far = R * 8;
  key.shadow.bias = -0.0002; key.shadow.normalBias = 0.6; key.shadow.radius = 4;
  scene.add(key, key.target);
  const rim = new THREE.DirectionalLight(0xbff5e6, 0.9); rim.position.set(ctr.x + R * 2, ctr.y + R, ctr.z - R * 2); scene.add(rim);
  const outs = [];
  for (const v of job.views) {
    const fov = v.fov || 30;
    const cam = (v.ortho)
      ? new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 5000)
      : new THREE.PerspectiveCamera(fov, W / H, 0.5, 5000);
    const az = (v.az || 0) * Math.PI / 180, el = (v.el || 0) * Math.PI / 180;
    const target = v.target ? new THREE.Vector3(v.target[0], v.target[2], -v.target[1]) : ctr.clone();
    const fit = v.fit || 1.0;
    const rad = 0.5 * Math.sqrt(size.x * size.x + size.y * size.y + size.z * size.z) * fit;
    const dist = v.dist || rad / Math.sin(fov * Math.PI / 360);
    // az=0 looks at the figure's front (figure faces -Y CAD == +Z three)
    cam.position.set(target.x + dist * Math.cos(el) * Math.sin(az), target.y + dist * Math.sin(el), target.z + dist * Math.cos(el) * Math.cos(az));
    if (v.ortho) { const h = rad; cam.left = -h * W / H; cam.right = h * W / H; cam.top = h; cam.bottom = -h; cam.updateProjectionMatrix(); }
    cam.lookAt(target);
    renderer.render(scene, cam);
    outs.push(renderer.domElement.toDataURL('image/png'));
  }
  return outs;
};
window.ready = true;
</script></body></html>`;
fs.writeFileSync(path.join(ROOT, 'page.html'), html);

const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--ignore-gpu-blocklist'] });
const page = await browser.newPage();
page.on('console', m => { if (m.type() === 'error') console.error('page:', m.text()); });
await page.goto(`http://127.0.0.1:${port}/page.html`);
await page.waitForFunction(() => window.ready === true);
for (const job of jobs) {
  const j = { ...job, glb: `/abs${path.resolve(job.glb)}` };
  const outs = await page.evaluate(async (jj) => await window.renderJob(jj), j);
  outs.forEach((d, i) => {
    const name = job.views[i].out;
    fs.writeFileSync(name, Buffer.from(d.split(',')[1], 'base64'));
    console.log('wrote', name);
  });
  await page.evaluate(() => { document.querySelectorAll('canvas').forEach(c => c.remove()); });
}
await browser.close();
server.close();
